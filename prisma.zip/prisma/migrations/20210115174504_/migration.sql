-- AlterTable
ALTER TABLE "Review" ADD COLUMN "averageRating" REAL;
